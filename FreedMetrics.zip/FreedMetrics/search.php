<?php

include "search_parsers.inc.php";

$servername = "localhost";
$dbusername = "TestUser";
// IMPORTANT, NEXT VARIABLE WILL HAVE TO CONTAIN THE PASSWORD FOR THE DATABASE (IF THERE IS NONE, LEAVE EMPTY)
$dbpassword = "123456789_AbC";
$dbname = "freedmetrics";

// Create connection
$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$user_query = $_GET["user_query"];
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
 <head>
    <meta charset="utf-8">
    <title><?php echo $_SESSION['username'];?>'s main Page</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css "href="registration/style.css">
  </head>

  <body>
    <div class="container">
      <p><?php print($user_query); ?></p>
    </div>
  </body>
</html>


