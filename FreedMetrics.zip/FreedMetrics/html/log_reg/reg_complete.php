<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1 style="text-align:center;margin-top:400px">A confirmation email was sent to the provided address, please activate your account</h1>
  </body>
</html>
