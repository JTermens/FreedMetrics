<?php

$baseDir = dirname($_SERVER['SCRIPT_FILENAME']);
$baseURL = dirname($_SERVER['SCRIPT_NAME']);

$incDir = "$baseDir/include";
$log_regDir = "$baseDir/log_reg";
$searchDir = "$baseDir/search";