<?php
/*
 * dbconn.inc.php
 * DB connection
 */

$host = 'localhost';
$bdname = 'freedmetrics';
$user = 'TestUser';
$pasword = '1234567890_AbC';

($mysqli = mysqli_connect($host, $user, $password)) or die(mysqli_error());
mysqli_select_db($mysqli, $dbname) or die(mysqli_error($mysqli));