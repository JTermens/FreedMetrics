# FreedMetrics
FreedMetrics is a free and open web application to analyse article-level metrics of academic papers. Is been thought and developed as the final project of the subject *Database and Web Development* (DBW) of the Msc. in Bioinformatics for Health Sciences at Universitat Pompeu Fabra, Barcelona.

For mor information, please contact us at freedmetrics@gmail.com

**Authors:** Òscar Camacho, Miguel Luengo, David Sotillo and Joan Térmens
